/*========================================================================================================================================================*/



// Вспомогательные модули плавного расскрытия и закрытия объекта ======================================================================================================================================================================
// SlideToggle
let _slideUp = (target, duration = 500) => {
	target.style.transitionProperty = 'height, margin, padding';
	target.style.transitionDuration = duration + 'ms';
	target.style.height = target.offsetHeight + 'px';
	target.offsetHeight;
	target.style.overflow = 'hidden';
	target.style.height = 0;
	target.style.paddingTop = 0;
	target.style.paddingBottom = 0;
	target.style.marginTop = 0;
	target.style.marginBottom = 0;
	window.setTimeout(() => {
		target.style.display = 'none';
		target.style.removeProperty('height');
		target.style.removeProperty('padding-top');
		target.style.removeProperty('padding-bottom');
		target.style.removeProperty('margin-top');
		target.style.removeProperty('margin-bottom');
		target.style.removeProperty('overflow');
		target.style.removeProperty('transition-duration');
		target.style.removeProperty('transition-property');
		target.classList.remove('_slide');
	}, duration);
}
let _slideDown = (target, duration = 500) => {
	target.style.removeProperty('display');
	let display = window.getComputedStyle(target).display;
	if (display === 'none')
		display = 'block';

	target.style.display = display;
	let height = target.offsetHeight;
	target.style.overflow = 'hidden';
	target.style.height = 0;
	target.style.paddingTop = 0;
	target.style.paddingBottom = 0;
	target.style.marginTop = 0;
	target.style.marginBottom = 0;
	target.offsetHeight;
	target.style.transitionProperty = "height, margin, padding";
	target.style.transitionDuration = duration + 'ms';
	target.style.height = height + 'px';
	target.style.removeProperty('padding-top');
	target.style.removeProperty('padding-bottom');
	target.style.removeProperty('margin-top');
	target.style.removeProperty('margin-bottom');
	window.setTimeout(() => {
		target.style.removeProperty('height');
		target.style.removeProperty('overflow');
		target.style.removeProperty('transition-duration');
		target.style.removeProperty('transition-property');
		target.classList.remove('_slide');
	}, duration);
}
let _slideToggle = (target, duration = 500) => {
	if (!target.classList.contains('_slide')) {
		target.classList.add('_slide');
		if (window.getComputedStyle(target).display === 'none') {
			return _slideDown(target, duration);
		} else {
			return _slideUp(target, duration);
		}
	}
}

/*========================================================================================================================================================*/
// Меню бургер

function menuBurger() {
	const burgerButton = document.querySelector('.icon-burger');
	const burgerBody = document.querySelector('.burger__body');

	burgerButton.addEventListener("click",function (e){
	burgerButton.classList.toggle('menu-open')
	burgerBody.classList.toggle('_active-burger')
	document.body.classList.toggle('_body-active')
});
}

/*========================================================================================================================================================*/
// Slider Swiper

// * if slider located in flex element, add min-width: 0; at parrent flex element of slider
if (document.querySelector('.slider')) { // Указываем скласс нужного слайдера
	// Создаем слайдер
	new Swiper('.slider', { // Указываем скласс нужного слайдера
		// Подключаем модули слайдера
		// для конкретного случая
		observer: true,
		observeParents: true,
		slidesPerView: 1,
		spaceBetween: 0,
		autoHeight: true,
		speed: 800,
		// grabCursor: true,
		
		// Connect with second slider
		// thums: {
		// 	swiper: secondSliderName,
		// },

		//touchRatio: 0,
		//simulateTouch: false,
		//loop: true,
		//preloadImages: false,
		//lazy: true,

		/*
		// Эффекты
		effect: 'fade',
		autoplay: {
			delay: 3000,
			disableOnInteraction: false,
		},
		*/

		// Пагинация
		/*
		pagination: {
			el: '.swiper-pagination',
			clickable: true,
		},
		*/

		// Скроллбар
		/*
		scrollbar: {
			el: '.swiper-scrollbar',
			draggable: true,
		},
		*/

		// Кнопки "влево/вправо"
		navigation: {
			prevEl: '.swiper-button-prev',
			nextEl: '.swiper-button-next',
		},

		// Брейкпоинты
		/*
		breakpoints: {
			320: {
				slidesPerView: 1,
				spaceBetween: 0,
				autoHeight: true,
			},
			768: {
				slidesPerView: 2,
				spaceBetween: 20,
			},
			992: {
				slidesPerView: 3,
				spaceBetween: 20,
			},
			1268: {
				slidesPerView: 4,
				spaceBetween: 30,
			},
		},
		*/
		// События
		on: {

		}
	});
}

/*========================================================================================================================================================*/
/*= Tipps =======================================================================================================================================================*/
/*========================================================================================================================================================*/
/*========================================================================================================================================================*/

const tipps = document.querySelectorAll('[data-tippy-content]');
if(tipps){
	tipps.forEach((tipp,i)=>{
		let hint = document.createElement('p')
		hint.className = 'hint'
		tipp.append(hint)
		let text = tipp.getAttribute('data-tippy-content')
		hint.innerText = text
		hint.style = 'opacity: 0;visibility: hidden'
		tipp.onmouseover = ()=>{
			hint.style = 'opacity: 1;visibility: visible'
		}
		tipp.onmouseout = ()=>{
			hint.style = 'opacity: 0;visibility: hidden'
		}
	
	})
}

/*========================================================================================================================================================*/
// Tabs 2
// Always opened
if(document.querySelector('[data-tabs]')){
	const tabTitles = document.querySelectorAll('[data-tabs-title]');
	const tabContents = document.querySelectorAll('[data-tabs-body]');

for (let i = 0; i < tabTitles.length; i++) {
	const tabTitle = tabTitles[i];
	tabContents[i].style.display = 'none'
	if(tabTitle.classList.contains('_tab-active')){
		tabContents[i].style.display = 'block'
	}
	tabTitle.onclick = () =>{
		for (let ind = 0; ind < tabContents.length; ind++) {
			const tabContent = tabContents[ind];
			tabTitles[ind].classList.remove('_tab-active')
			tabContent.style.display = 'none'
		}
		tabTitle.classList.add('_tab-active')
		tabContents[i].style.display = 'block'
	}
}
} 
//  [data-tabs-closed] Can be closed
if(document.querySelector('[data-tabs-closed]')){
	const tabTitles = document.querySelectorAll('[data-tabs-title]');
	const tabContents = document.querySelectorAll('[data-tabs-body]');

	for (let i = 0; i < tabTitles.length; i++) {
		const tabTitle = tabTitles[i];
		if(tabTitle.classList.contains('_tab-active')){
			tabContents[i].classList.add('_opened')
		}
		tabTitle.onclick = () =>{
			for (let ind = 0; ind < tabContents.length; ind++) {
				const tabContent = tabContents[ind];
				if(!tabContents[i].classList.contains('_opened')){
					tabContent.classList.remove('_opened')
					tabTitles[ind].classList.remove('_tab-active')
				}
			}
			tabTitle.classList.toggle('_tab-active')
			tabContents[i].classList.toggle('_opened')
		}

	}
}

// Closing winodows on clicking other areas
/*
window.onclick = (e) =>{
	const tabContents = document.querySelectorAll('[data-tabs-body]');
	const tabTitles = document.querySelectorAll('[data-tabs-title]');

	if(!e.target.closest('')){
		for (let index = 0; index < tabContents.length; index++) {
			const tbCont = tabContents[index];
			tbCont.classList.remove('_opened')
			tabTitles[index].classList.remove('_tab-active')
		}
	}
}
*/


/*========================================================================================================================================================*/
// Dynamic adaptive

// Breakpoints
let tablet = 991.98
let mobile = 767.98
let mobileSmall = 479.98

let md2 = tablet
let md3 = mobile
let md4 = mobileSmall

// Snippet da

// main function
function dynamicAdaptive(da_elements,da_destination,da_breakpoint = 991.98,num,da_type = 'max') {
   let parrent_element;
   for (let index = 0; index < da_elements.length; index++) {
      const el = da_elements[index];
      parrent_element = el.parentElement
      let which = null ? num = false : da_destination.children[num]
      let media = window.matchMedia(`(${da_type}-width: ${da_breakpoint}px)`);
      if (media.matches) {
         da_destination.insertBefore(el,which)
      }
      media.addListener(dynamic_adapt);
      function dynamic_adapt(e) {
            if (media.matches) {
               da_destination.insertBefore(el,which)
            }else{
               parrent_element.insertBefore(el,null)
            }
      }
   }
}
