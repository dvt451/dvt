const Menu = [
   'Services',
   'About us',
   'Our team',
   'Our works',
   'Contacts',
   'Appointment',
]
export default Menu;