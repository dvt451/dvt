/*========================================================================================================================================================*/
// scroll

if(document.querySelector('[data-scroll]')){
	const dataScroll = document.querySelectorAll('[data-scroll]');
	function scroll(element,num = 0) {
		// if the bottom of display pass or get to the element, elements will appear
		if(element.offsetTop + num < y){
			element.classList.add('_scroll-active')
		}else{
			element.classList.remove('_scroll-active')
		}
	}
	window.addEventListener("scroll",function (e){
		// making scroll to count from the bottom of display
		y = window.scrollY + window.innerHeight
		for (let i = 0; i < dataScroll.length; i++) {
			const item = dataScroll[i];
			scroll(item)
		}
	})
}