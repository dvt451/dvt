import Select from './Components/Libs/Select';
import Home from './Components/pages/home/Home';
import './css/style.css'
import Header from './Components/Header/Header'
import Footer from './Components/General/Footer'
import { BrowserRouter, Route, Router, Routes } from 'react-router-dom'
import MyContextProvider from './Components/General/MyContextProvider';
import Notfound from './Components/General/Notfound'

function App() {
    return (
        <div className="App">
         <MyContextProvider>
            <BrowserRouter>
               <Header />
               <Routes>
                  <Route element={<Home />} path=''/>
                  <Route path='*' element={<Notfound />}/>
               </Routes>
               <Footer />
            </BrowserRouter>
         </MyContextProvider>
        </div>
    );
}

export default App;