import React from 'react'

export default function Notfound() {
  return (
    <div className='nopage'>
      <div className="nopage__content"style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            margin: 'auto',
            width: '100%',
            height: '80vh'
         }}>
         <p className="nopage__text" style={{
            fontSize: '40px',
            fontWeight: 700,
            textTransform: 'uppercase',
            textAlign: 'center',
         }}>
            Something wrong
            <br />
            <br />
            Page not found
         </p>
      </div>
    </div>
  )
}
