import React, { useContext } from 'react';
import { MyContext } from '../../General/MyContextProvider';
import Select from '../../Libs/Select';

export default function Home() {
  const _ = useContext(MyContext);
   const opt= ['BMW','Mercedes','TESLA','FORD']
  return (
    <div>
      <h1>Select</h1>
      <Select arrayList={opt} selectedNum={0}/>
    </div>
  );
}
