gulp watch
npm start

Setups

  -  react-router-dom
  -  useContext