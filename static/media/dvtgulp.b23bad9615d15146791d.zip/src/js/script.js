if(document.querySelector('.logo')){
   const logos = document.querySelectorAll('.logo');
   for (let i = 0; i < logos.length; i++) {
      const logo = logos[i];
      logo.innerHTML = ''
   }
}